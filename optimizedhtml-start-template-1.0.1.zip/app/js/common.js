$(function() {

	// Custom JS
	$(".menu-toggle").click(function() {
	  $(this).toggleClass("on");
	  $(".menu-main").slideToggle();
	  return false;
	});

	$("#owl-demo").owlCarousel({
		items: 1,
		autoplay: true,
		autoplayTimeout: 3000,
		loop: true,
	});

	$.fn.maphilight.defaults = {
    fill: true,
    fillColor: 'ff0000',
    fillOpacity: 0.3,
    stroke: false,
    strokeColor: 'ff0000',
    strokeOpacity: 1,
    strokeWidth: 1,
    fade: true,
    alwaysOn: false,
    neverOn: false,
    groupBy: false,
    wrapClass: true,
    shadow: false,
    shadowX: 0,
    shadowY: 0,
    shadowRadius: 6,
    shadowColor: '000000',
    shadowOpacity: 0.8,
    shadowPosition: 'outside',
    shadowFrom: false
  }
  $(function() {
      $('.map').maphilight();
      $('#squidheadlink').mouseover(function(e) {
          $('#squidhead').mouseover();
      }).mouseout(function(e) {
          $('#squidhead').mouseout();
      }).click(function(e) { e.preventDefault(); });
  });


});
